/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;

public class Shelve {

  private String typeOfReading;

  private String nameOfBook;
  Vector <Reader>v=new Vector<>();
//    public Reader 1;
//    public Vector  1;
  public Shelve(String typeOfReading, String nameOfBook) {
        this.typeOfReading = typeOfReading;
        this.nameOfBook = nameOfBook;
  }

    Shelve() {
        
    }

    public void setTypeOfReading(String typeOfReading) {
        this.typeOfReading = typeOfReading;
    }

    public void setNameOfBook(String nameOfBook) {
        this.nameOfBook = nameOfBook;
    }

    public String getTypeOfReading() {
        return typeOfReading;
    }

    public String getNameOfBook() {
        return nameOfBook;
    }
  public void addShelve(String nameOfBook , String typeOfReading , String shelveid) {
      Scanner m=new Scanner(System.in);
        try {
                String host ="jdbc:mysql://localhost/e_book";
                String uName = "root";
                String uPass= "nourhan";
                Connection con = DriverManager.getConnection( host, uName, uPass );
                Statement stmt = con.createStatement( );
                int insertCount = stmt.executeUpdate("INSERT INTO shelve(bookname,typeofreading,shelveID) VALUES('"+nameOfBook+"','"+typeOfReading+"','"+shelveid+"')");
                String query="INSERT INTO shelve(bookname,typeofreading,shelveID) VALUES('"+nameOfBook+"','"+typeOfReading+"','"+shelveid+"')";
                PreparedStatement preparedStatement = con.prepareStatement(query);
                insertCount = preparedStatement.executeUpdate();
        }
        catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
        }
      
  }

  public void editShelve(String name,String typeOfReading) {
      try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );  
            int update = stmt.executeUpdate("update shelve set typeOfReading='"+typeOfReading+"'where bookname='"+name+"'");
            String query="update shelve set typeofreading='"+typeOfReading+"'where bookname='"+name+"'";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            update = preparedStatement.executeUpdate();
        }
            catch ( SQLException err ) {
                   System.out.println( err.getMessage( ) );
             }  
  }

  public void removeShelve(String shelveid) {
      try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );  
            int delete = stmt.executeUpdate("delete from shelve where shelveID='"+shelveid+"'");
            String query="delete from shelve where shelveID='"+shelveid+"'";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            delete = preparedStatement.executeUpdate();
        }
            catch ( SQLException err ) {
                   System.out.println( err.getMessage( ) );
             }  
  }

}