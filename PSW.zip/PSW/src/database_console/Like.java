/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;

public class Like {
    private String dateL;
    public String timeL;
    public String nameOfOwnerL;

    public Like(String dateL, String timeL, String nameOfOwnerL) {
          this.dateL = dateL;
          this.timeL = timeL;
          this.nameOfOwnerL = nameOfOwnerL;
    }

    Like() {
        
    }

    public void setDateL(String dateL) {
          this.dateL = dateL;
      }

    public void setTimeL(String timeL) {
        this.timeL = timeL;
    }

    public void setNameOfOwnerL(String nameOfOwnerL) {
        this.nameOfOwnerL = nameOfOwnerL;
    }

    public String getDateL() {
        return dateL;
    }

    public String getTimeL() {
        return timeL;
    }

    public String getNameOfOwnerL() {
        return nameOfOwnerL;
    }
   public void addLike(String ID) {
       try{
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            String SQL = "SELECT * FROM post";
            ResultSet rs = stmt.executeQuery( SQL );
            while(rs.next( )){
                if(ID.compareTo(rs.getString("postID"))==0){
                    System.out.println("UPDATE post SET numOfLike=numOfLike+'"+1+"' WHERE postID='"+ID+"'");
                    int update = stmt.executeUpdate("UPDATE post SET numOfLike=numOfLike+'"+1+"' WHERE postID='"+ID+"'");
                    String query="UPDATE post SET numOfLike=numOfLike+'"+1+"' WHERE postID='"+ID+"'";
                    PreparedStatement preparedStatement = con.prepareStatement(query);
                    update = preparedStatement.executeUpdate();
                }
            }
            
      }
       catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
        }
       
   }

}