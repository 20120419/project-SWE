package database_console;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.sql.PreparedStatement;

public class DBConnect {
    public static void main(String[] args) throws SQLException {
       welcom w=new welcom();
       w.show();
      
    }
    
}
