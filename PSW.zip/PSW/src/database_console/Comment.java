/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.util.Vector;

public class Comment {

  private String statmentC;

  private String dateC;

  private String nameOfOwnerC;

  private String timeC;
  Vector <Like>v=new Vector<>();
//    public Vector  *;
//    public Vector  *;
//    public Vector  myPost;
//    public Vector  *;
//    public Vector  myReview;
public Comment(String statmentC, String dateC, String nameOfOwnerC, String timeC) {
        this.statmentC = statmentC;
        this.dateC = dateC;
        this.nameOfOwnerC = nameOfOwnerC;
        this.timeC = timeC;
    }

    Comment() {
        
    }
        

    public void setStatmentC(String statmentC) {
        this.statmentC = statmentC;
    }

    public void setDateC(String dateC) {
        this.dateC = dateC;
    }

    public void setNameOfOwnerC(String nameOfOwnerC) {
        this.nameOfOwnerC = nameOfOwnerC;
    }

    public void setTimeC(String timeC) {
        this.timeC = timeC;
    }

    public String getStatmentC() {
        return statmentC;
    }

    public String getDateC() {
        return dateC;
    }

    public String getNameOfOwnerC() {
        return nameOfOwnerC;
    }

    public String getTimeC() {
        return timeC;
    }

  public void addComment() {
  }

}
