/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.util.Vector;

public class Adminstrator {

  private String adminName;

  private String adminMail;

  private String adminId;

    //public Book m;
    //public Vector  *;
    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public void setAdminMail(String adminMail) {
        this.adminMail = adminMail;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getAdminName() {
        return adminName;
    }

    public String getAdminMail() {
        return adminMail;
    }

    public String getAdminId() {
        return adminId;
    }
 
    public void addSuggestions() {
    }
}