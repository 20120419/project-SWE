/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;

public class Book {

  private String title;

  private String edition;

  private String authorName;

  private String publisherName;

  private String date;

  private Integer bookId;
  private int rate;
    public Vector  my;
    public Vector  myReader;
    public Adminstrator ggh;
    Vector <Book> vec=new Vector<Book>();
   // public Reader myReader;
   // public Vector  1;
    //public Vector  *;

    public Book() {
    }

    public Book(String title, String edition, String authorName, String publisherName, String date, Integer bookId) {
        this.title = title;
        this.edition = edition;
        this.authorName = authorName;
        this.publisherName = publisherName;
        this.date = date;
        this.bookId = bookId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setPublisherName(String publisherName) {
        this.publisherName = publisherName;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getEdition() {
        return edition;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getPublisherName() {
        return publisherName;
    }

    public String getDate() {
        return date;
    }

    public Integer getBookId() {
        return bookId;
    }

    
  public void addBook(String BID,String Btitle,String authername,String publishername,String Bedition,String Bdate) {
      Scanner m=new Scanner(System.in);
        try {
                String host ="jdbc:mysql://localhost/e_book";
                String uName = "root";
                String uPass= "nourhan";
                Connection con = DriverManager.getConnection( host, uName, uPass );
                Statement stmt = con.createStatement( ); 
                String result = "SELECT bookId FROM book";
                ResultSet rs = stmt.executeQuery( result );
                int starRate=0;
                int insertCount = stmt.executeUpdate("INSERT INTO book(bookId,booktitle,edition,authorName,publisherName,bookdate,rate) VALUES('"+BID+"','"+Btitle+"','"+Bedition+"','"+authername+"','"+publishername+"','"+Bdate+"','"+starRate+"')");
                String query="INSERT INTO book(bookId,booktitle,edition,authorName,publisherName,bookdate,rate) VALUES('"+BID+"','"+Btitle+"','"+Bedition+"','"+authername+"','"+publishername+"','"+Bdate+"','"+starRate+"')";
                PreparedStatement preparedStatement = con.prepareStatement(query);
                insertCount = preparedStatement.executeUpdate();
        }
        catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
        }
  }

  public void removeBook(String choice,String word) {
      System.out.println(choice);
        try {
                String host ="jdbc:mysql://localhost/e_book";
                String uName = "root";
                String uPass= "nourhan";
                Connection con = DriverManager.getConnection( host, uName, uPass );
                Statement stmt = con.createStatement( ); 
                String result = "SELECT * FROM book";
                ResultSet rs = stmt.executeQuery( result );
                    //delete by book title
                    int deleteBytitle = stmt.executeUpdate("delete from book where booktitle='"+word+"'");
                    String query1="delete from book where booktitle='"+word+"'";
                    PreparedStatement preparedStatement = con.prepareStatement(query1);
                    deleteBytitle = preparedStatement.executeUpdate();

                    //delete by auther name
                    int deleteByauther = stmt.executeUpdate("delete from book where authorName='"+word+"'");
                    String query2="delete from book where authorName='"+word+"'";
                    preparedStatement = con.prepareStatement(query2);
                    deleteByauther = preparedStatement.executeUpdate();

                    //delete by publisher name
                    int deleteBypublisher = stmt.executeUpdate("delete from book where publisherName='"+word+"'");
                    String query3="delete from book where publisherName='"+word+"'";
                     preparedStatement = con.prepareStatement(query3);
                    deleteBypublisher= preparedStatement.executeUpdate();
 
                    //delete by  edition
                    int deleteByedition = stmt.executeUpdate("delete from book where edition='"+word+"'");
                    String query4="delete from book where edition='"+word+"'";
                     preparedStatement = con.prepareStatement(query4);
                    deleteByedition = preparedStatement.executeUpdate();

        }
        catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
        }
      
      
  }

  public void rateBook(String name,String rate) {
      System.out.println("rate");
      try{
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            int update = stmt.executeUpdate("update book set  rate='"+rate+"' where booktitle='"+name+"'");
            String query="update book set  rate='"+rate+"' where booktitle='"+name+"'";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            update = preparedStatement.executeUpdate();
            
      }
       catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
        } 
      
  }

  public void searchBook(String searchTitle) {
      try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            String SQL = "SELECT * FROM book ";
            ResultSet rs = stmt.executeQuery( SQL );
            while(rs.next( )){
                String givenTitle = rs.getString("booktitle");
                if(searchTitle.equals(givenTitle)){
                   System.out.println("this book is exist");
                   
                   return;
                }     
            }
           System.out.println("this book not exist");

      }
        catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
        } 
  }

  public void ViewBook(String searchTitle) {
      try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            String SQL = "SELECT * FROM book ";
            ResultSet rs = stmt.executeQuery( SQL );
            while(rs.next( )){
                String givenTitle = rs.getString("booktitle");
                if(searchTitle.equals(givenTitle)){
                   System.out.println("book tiltle is "+rs.getString("booktitle")+"\n"+"edition is "+rs.getString("edition")+"\n"+"auther name is "+rs.getString("authorName")+"\n"+"publisher name is "+rs.getString("publisherName"));
                   
                   return;
                }
            }
           System.out.println("this book not exist");
      }
        catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
        } 
  }

}