/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;

public class Review {

  public String startReading;

  public String endReading;

  public String timeR;

  public String dateR;

    public Vector  myLike;
    public Vector  myComment;
    Vector <Reader>v=new Vector<>();
   // public Vector  1;
  public Review(String startReading, String endReading, String timeR, String dateR) {
        this.startReading = startReading;
        this.endReading = endReading;
        this.timeR = timeR;
        this.dateR = dateR;
    }

    Review() {
        
    }

    public void setStartReading(String startReading) {
        this.startReading = startReading;
    }

    public void setEndReading(String endReading) {
        this.endReading = endReading;
    }

    public void setTimeR(String timeR) {
        this.timeR = timeR;
    }

    public void setDateR(String dateR) {
        this.dateR = dateR;
    }

    public String getStartReading() {
        return startReading;
    }

    public String getEndReading() {
        return endReading;
    }

    public String getTimeR() {
        return timeR;
    }

    public String getDateR() {
        return dateR;
    }

  public String viewReview() {
  return null;
  }

  public void addReview(String startReading,String timeR,String endReading,String dateR) {
      Scanner n=new Scanner(System.in);
       try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );  
	    int insertCount = stmt.executeUpdate("INSERT INTO Reviews( startReading,timeR,endReading,dateR) VALUES('"+startReading+"','"+timeR+"','"+endReading+"','"+dateR+"')");
            String query="INSERT INTO Reviews( startReading,timeR,endReading,dateR) VALUES('"+startReading+"','"+timeR+"','"+endReading+"','"+dateR+"'";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            insertCount = preparedStatement.executeUpdate();
        }
            catch ( SQLException err ) {
                   System.out.println( err.getMessage( ) );
             }
              
  }
  public void addReviewComment() {
      
  }

}