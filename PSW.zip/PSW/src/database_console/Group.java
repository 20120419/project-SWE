/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class Group {

  public String groupName;

  public int numOFMembers;

  public String startDate;
  Vector <Reader>v=new Vector<>();
//    public Vector  1;
//    public Vector  my;
//    public Vector  *;
    public Group(String groupName, int numOFMembers, String startDate) {
        this.groupName = groupName;
        this.numOFMembers = numOFMembers;
        this.startDate = startDate;
    }

    Group() {
        
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public void setNumOFMembers(int numOFMembers) {
        this.numOFMembers = numOFMembers;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getGroupName() {
        return groupName;
    }

    public int getNumOFMembers() {
        return numOFMembers;
    }

    public String getStartDate() {
        return startDate;
    }
  
  public void createGroup(String name,String date,int num) {
        try{
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            int insertCount = stmt.executeUpdate("INSERT INTO groups( groupName,numOfMember,startdate) VALUES('"+name+"','"+num+"','"+date+"')");
            String query="INSERT INTO groups( groupName,numOfMember,startdate) VALUES('"+name+"','"+num+"','"+date+"')";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            insertCount = preparedStatement.executeUpdate();
           
            
      }
       catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
        } 
  }

  public void addFriend(String name) {
       try{
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            String SQL = "SELECT * FROM groups";
            ResultSet rs = stmt.executeQuery( SQL );
            while(rs.next( )){
                if(name.compareTo(rs.getString("groupName"))==0){
                   int update = stmt.executeUpdate("UPDATE groups SET numOfMember=numOfMember+'"+1+"' WHERE groupName='"+name+"'");
                   String query="UPDATE groups SET numOfMember=numOfMember+'"+1+"' WHERE groupName='"+name+"'";
                   PreparedStatement preparedStatement = con.prepareStatement(query);
                    update = preparedStatement.executeUpdate();
                }
            }
            
      }
       catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
        }
  }

  public void join(String name) {
       try{
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            String SQL = "SELECT * FROM groups";
            ResultSet rs = stmt.executeQuery( SQL );
            while(rs.next( )){
                String gname = rs.getString("groupName");
                if(name.compareTo(rs.getString("groupName"))==0){
                   int update = stmt.executeUpdate("UPDATE groups SET numOfMember=numOfMember+'"+1+"' WHERE groupName='"+name+"'");
                   String query="UPDATE groups SET numOfMember=numOfMember+'"+1+"' WHERE groupName='"+name+"'";
                   PreparedStatement preparedStatement = con.prepareStatement(query);
                    update = preparedStatement.executeUpdate();
                    System.out.println("You are accepted");
                }
            }
            
      }
       catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
        }
  }

}