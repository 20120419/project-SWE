/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;

public class Post {

  public String statmentP;

  private String dateP;

  public String nameOfOwnerP;

  public String timeP;
  Vector <Group>v=new Vector<>();
//    public Vector  *;
//    public Vector  myComment;
//    public Vector  *;
//    public Vector  *;
//    public Vector  1;
  public Post(){
      
  }
  public Post(String statmentP, String dateP, String nameOfOwnerP, String timeP) {
        this.statmentP = statmentP;
        this.dateP = dateP;
        this.nameOfOwnerP = nameOfOwnerP;
        this.timeP = timeP;
    }

    

    public void setStatmentP(String statmentP) {
        this.statmentP = statmentP;
    }

    public void setDateP(String dateP) {
        this.dateP = dateP;
    }

    public void setNameOfOwnerP(String nameOfOwnerP) {
        this.nameOfOwnerP = nameOfOwnerP;
    }

    public void setTimeP(String timeP) {
        this.timeP = timeP;
    }

    public String getStatmentP() {
        return statmentP;
    }

    public String getDateP() {
        return dateP;
    }

    public String getNameOfOwnerP() {
        return nameOfOwnerP;
    }

    public String getTimeP() {
        return timeP;
    }
  

  public void addPost(String statment,String nameOfOwner,String date,String time,String  postid)  {
      Scanner n=new Scanner(System.in);
        try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );  
            int numofLike=0;
	    int insertCount = stmt.executeUpdate("INSERT INTO post( statmentP,dateP,nameOfOwnerP,timeP,postID,numOfLike) VALUES('"+statment+"','"+date+"','"+nameOfOwner+"','"+time+"','"+postid+"','"+numofLike+"')");
            String query="INSERT INTO post( statmentP,dateP,nameOfOwnerP,timeP) VALUES('"+statment+"','"+date+"','"+nameOfOwner+"','"+time+"','"+postid+"')";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            insertCount = preparedStatement.executeUpdate();
        }
            catch ( SQLException err ) {
                   System.out.println( err.getMessage( ) );
             }
              
        
  }
    public void removePost(String Owner, String time){
        Scanner n=new Scanner(System.in);
        try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );  
            int deleteCount = stmt.executeUpdate("delete from post where nameOfOwnerP='"+Owner+"' and timeP='"+time+"'");
            String query="delete from post where nameOfOwnerP='"+Owner+"' and timeP='"+time+"'";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            deleteCount = preparedStatement.executeUpdate();
        }
            catch ( SQLException err ) {
                   System.out.println( err.getMessage( ) );
             }  
}  

  public void addReader() {
  }

}
