/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database_console;

/**
 *
 * @author trast
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;

public class Reader {

  private String readerName;

  private String readerMail;

  private Integer readerId;
  
  private String readerpassword;
  Vector <Book>v=new Vector<>();

//    public Vector  myBook;
//    public Book myBook;
//    public Vector  *;
//    public Vector  *;
//    public Vector  *;
//    public Shelve *;
//    public Vector  *;
public Reader() {
        readerName ="";
        readerMail ="";
        readerId =0;
        readerpassword ="";
  }
  public Reader(String readerName, String readerMail, Integer readerId, String readerpassword) {
        this.readerName = readerName;
        this.readerMail = readerMail;
        this.readerId = readerId;
        this.readerpassword = readerpassword;
  }

    public void setReaderName(String readerName) {
        this.readerName = readerName;
    }

    public void setReaderMail(String readerMail) {
        this.readerMail = readerMail;
    }

    public void setReaderId(Integer readerId) {
        this.readerId = readerId;
    }

    public void setReaderpassword(String readerpassword) {
        this.readerpassword = readerpassword;
    }

    public String getReaderName() {
        return readerName;
    }

    public String getReaderMail() {
        return readerMail;
    }

    public Integer getReaderId() {
        return readerId;
    }

    public String getReaderpassword() {
        return readerpassword;
    }

    public void signUp(String mail,String password,String name,String id ){
        try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            Scanner k=new Scanner(System.in);
            String SQL = "SELECT * FROM reader";
            ResultSet rs = stmt.executeQuery( SQL );
            while(rs.next( )){
                String rmail = rs.getString("readermail");
                if(mail.compareTo(rs.getString("readermail"))== 0){
                   System.out.println("this email sign up before");
                    return;
                }
            }  
            int insertCount = stmt.executeUpdate("INSERT INTO reader(readermail,readerpassword,readerId,readerName) VALUES('"+mail+"','"+password+"',"+id+",'"+name+"')");
            String query="INSERT INTO reader(readermail,readerpassword,readerId,readerName) VALUES('"+mail+"','"+password+"',"+id+",'"+name+"')";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            insertCount = preparedStatement.executeUpdate();
            System.out.println("sign up successful");
            
        }
        catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
        } 
    }
    
    public void logIn(String mail,String password){
        try {
            String host ="jdbc:mysql://localhost/e_book";
            String uName = "root";
            String uPass= "nourhan";
            Connection con = DriverManager.getConnection( host, uName, uPass );
            Statement stmt = con.createStatement( );
            Scanner k=new Scanner(System.in);
            String SQL = "SELECT * FROM reader";
            ResultSet rs = stmt.executeQuery( SQL );
            while(rs.next( )){
                String rmail = rs.getString("readermail");
                String pass = rs.getString("readerpassword");
                System.out.println(rs.getString("readermail")+rs.getString("readerpassword"));
                if(mail.compareTo(rs.getString("readermail"))== 0 && password.compareTo(rs.getString("readerpassword")) == 0){
                    System.out.println("this email log in successful");
                    signUp_In s=new signUp_In();
                    s.hide();
                    EBookGUI b=new EBookGUI();
                    b.show();
                    return;
                } 
            }
            System.out.println("this email not register");
                    
                
        }
       catch ( SQLException err ) {
              System.out.println( err.getMessage( ) );
              
      }
        
    }
    public String showNewsFeed() {
        return null;
    }

  public void addReader() {
  }
  

}